import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Web3Provider } from "@/components/providers/web3-provider"
import { AuthProvider } from "@/components/providers/auth-provider"
import { RootErrorHandler } from "./root-error-handler"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" })

export const metadata: Metadata = {
  title: "Rialo | Decentralized Exchange",
  description: "Trade with confidence on Rialo DEX - Protocol-level 2FA security on Solana Testnet",
  generator: "v0.app",
  keywords: ["DEX", "decentralized exchange", "crypto", "trading", "Solana", "Testnet", "Web3", "Rialo"],
  authors: [{ name: "Rialo" }],
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
}

export const viewport: Viewport = {
  themeColor: "#010101",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} ${geistMono.variable} font-sans antialiased`}>
        <RootErrorHandler />
        <Web3Provider>
          <AuthProvider>{children}</AuthProvider>
        </Web3Provider>
        <Analytics />
      </body>
    </html>
  )
}
