'use client'

import { useEffect } from 'react'

export function RootErrorHandler() {
  useEffect(() => {
    // Suppress browser extension errors
    const originalError = window.onerror
    window.onerror = function (
      message: string | Event,
      source?: string,
      lineno?: number,
      colno?: number,
      error?: Error
    ) {
      // Ignore ethereum property redefinition errors
      if (
        typeof message === 'string' &&
        message.includes('Cannot redefine property')
      ) {
        console.debug('[v0] Suppressed browser extension error')
        return true
      }

      if (originalError) {
        return originalError.call(window, message, source, lineno, colno, error)
      }
      return false
    }

    return () => {
      window.onerror = originalError
    }
  }, [])

  return null
}
