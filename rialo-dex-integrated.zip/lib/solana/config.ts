/**
 * RIALO DEX - Solana Testnet Configuration
 * 
 * Environment Variables Required:
 * - NEXT_PUBLIC_DEX_PROGRAM_ID: Deployed Anchor program ID on Testnet
 * - NEXT_PUBLIC_RIAL_MINT: RIAL token mint address on Testnet
 * - NEXT_PUBLIC_SOLANA_RPC: (Optional) Custom Testnet RPC URL
 */

// Solana Testnet RPC - use default public RPC to avoid module loading issues
export const TESTNET_RPC = process.env.NEXT_PUBLIC_SOLANA_RPC || 'https://api.testnet.solana.com';
export const DEVNET_RPC = TESTNET_RPC; // Backward compatibility - points to testnet
export const NETWORK = 'testnet'; // Always use testnet

// ⚠️ UPDATE THESE WITH YOUR DEPLOYED ADDRESSES ⚠️
// Using string addresses to avoid PublicKey initialization issues in preview environment
const TOKEN_PROGRAM = 'TokenkegQfeZyiNwAJsyFbPVwwQQftas5call5pVM5gdk'; // SPL Token Program
const USDC_MINT = '4zMMC9srt5Ri5X14Gye5QZ5yi9GeZymQuNCjaSstB5Ty'; // USDC-Dev on Testnet

// Export as strings - convert to PublicKey in hooks/components where needed
export const DEX_PROGRAM_ID_STR = process.env.NEXT_PUBLIC_DEX_PROGRAM_ID || TOKEN_PROGRAM;
export const RIAL_MINT_STR = process.env.NEXT_PUBLIC_RIAL_MINT || USDC_MINT;

// Backward compatibility - export string versions with original names
export const DEX_PROGRAM_ID = DEX_PROGRAM_ID_STR;
export const RIAL_MINT = RIAL_MINT_STR;

// Network configuration
export const NETWORKS = {
  testnet: {
    name: 'Solana Testnet',
    rpcUrl: TESTNET_RPC,
    explorerUrl: 'https://solscan.io',
    explorerUrlParam: '?cluster=testnet',
  },
};

// Token mint strings on Solana Testnet
export const TOKEN_MINTS = {
  RIAL: RIAL_MINT_STR,
  USDC: USDC_MINT, // USDC-Dev on Testnet
  SOL: 'native', // Native SOL uses special handling
};

// Default faucet settings (matches smart contract)
export const FAUCET_CONFIG = {
  amount: 100_000_000n, // 100 RIAL (with 6 decimals)
  cooldownSeconds: 86400, // 24 hours
  requestsPerDay: 1,
};

// Pool configuration (matches smart contract)
export const POOL_CONFIG = {
  feeBps: 25, // 0.25% fee
  minLiquidity: 1_000_000n, // 1 RIAL
};

// PDA seeds (must match Anchor program)
export const SEEDS = {
  DEX_CONFIG: Buffer.from('dex_config'),
  FAUCET_REQUEST: Buffer.from('faucet_request'),
  POOL: Buffer.from('pool'),
  BRIDGE_TX: Buffer.from('bridge_tx'),
};

// Destination chains for bridge (must match Anchor program)
export const BRIDGE_CHAINS = {
  SOLANA_TESTNET: 0,
  ETHEREUM_SEPOLIA: 1,
  POLYGON_MUMBAI: 2,
} as const;

// Transaction settings
export const TRANSACTION_CONFIG = {
  maxRetries: 5,
  blockhashCacheExpiry: 120000, // 2 minutes
  confirmationTimeout: 30000, // 30 seconds
};

// Solscan explorer helper
export function getSolscanUrl(txHash: string): string {
  return `https://solscan.io/tx/${txHash}?cluster=testnet`;
}

export function getSolscanAddressUrl(address: string): string {
  return `https://solscan.io/address/${address}?cluster=testnet`;
}

// Helper to create PublicKey safely when needed (deferred to runtime)
export function toPublicKey(address: string) {
  try {
    const { PublicKey } = require('@solana/web3.js');
    return new PublicKey(address);
  } catch (error) {
    console.error('[v0] Failed to create PublicKey:', error);
    return null;
  }
}
