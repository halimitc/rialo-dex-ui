"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"

interface PhantomProvider {
  connect: (options?: { onlyIfTrusted?: boolean }) => Promise<{ publicKey: { toString: () => string } }>
  disconnect: () => Promise<void>
  signAndSendTransaction: (tx: unknown) => Promise<{ signature: string }>
  signMessage: (message: Uint8Array) => Promise<{ signature: Uint8Array }>
  on: (event: string, callback: (...args: unknown[]) => void) => void
  removeListener: (event: string, callback: (...args: unknown[]) => void) => void
  isPhantom?: boolean
}

function getPhantomProvider(): PhantomProvider | null {
  if (typeof window !== "undefined" && (window as unknown as { solana?: PhantomProvider }).solana?.isPhantom) {
    return (window as unknown as { solana?: PhantomProvider }).solana || null
  }
  return null
}

interface Web3ContextType {
  address: string | null
  isConnected: boolean
  isConnecting: boolean
  network: string
  connect: () => Promise<void>
  disconnect: () => void
}

const Web3Context = createContext<Web3ContextType>({
  address: null,
  isConnected: false,
  isConnecting: false,
  network: "testnet",
  connect: async () => {},
  disconnect: () => {},
})

export function useWeb3() {
  return useContext(Web3Context)
}

interface Web3ProviderProps {
  children: ReactNode
}

export function Web3Provider({ children }: Web3ProviderProps) {
  const [address, setAddress] = useState<string | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)

  const isConnected = !!address
  const network = "testnet" // Solana Testnet

  const handleConnect = useCallback((publicKey: unknown) => {
    const pk = publicKey as { toString: () => string }
    setAddress(pk.toString())
  }, [])

  const handleDisconnect = useCallback(() => {
    setAddress(null)
  }, [])

  useEffect(() => {
    const phantom = getPhantomProvider()
    if (!phantom) return

    // Check if already connected
    const checkConnection = async () => {
      try {
        const response = await phantom.connect({ onlyIfTrusted: true })
        setAddress(response.publicKey.toString())
      } catch {
        // Not connected yet
      }
    }

    checkConnection()

    // Listen for connect/disconnect
    phantom.on("connect", handleConnect)
    phantom.on("disconnect", handleDisconnect)

    return () => {
      phantom.removeListener("connect", handleConnect)
      phantom.removeListener("disconnect", handleDisconnect)
    }
  }, [handleConnect, handleDisconnect])

  const connect = async () => {
    const phantom = getPhantomProvider()
    if (!phantom) {
      window.open("https://phantom.app/", "_blank")
      return
    }

    setIsConnecting(true)
    try {
      const response = await phantom.connect()
      setAddress(response.publicKey.toString())
    } catch (error) {
      console.error("Error connecting wallet:", error)
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnect = async () => {
    const phantom = getPhantomProvider()
    if (phantom) {
      try {
        // Phantom doesn't have a real disconnect, so we manually remove listeners
        // and clear the address to simulate disconnection
        phantom.removeListener("connect", handleConnect)
        phantom.removeListener("disconnect", handleDisconnect)
        
        // Try to call disconnect if available
        if (typeof phantom.disconnect === "function") {
          await phantom.disconnect()
        }
      } catch (error) {
        console.error("[v0] Error disconnecting:", error)
      }
    }
    // Force set address to null
    setAddress(null)
    // Also clear from localStorage if stored
    if (typeof window !== "undefined") {
      localStorage.removeItem("walletAddress")
    }
    console.log("[v0] Wallet disconnected")
  }

  return (
    <Web3Context.Provider
      value={{
        address,
        isConnected,
        isConnecting,
        network,
        connect,
        disconnect,
      }}
    >
      {children}
    </Web3Context.Provider>
  )
}
