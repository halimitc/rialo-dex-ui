"use client"

import { useState, useEffect } from "react"
import { useWeb3 } from "@/components/providers/web3-provider"
import { useAuth } from "@/components/providers/auth-provider"
import { useSwapTokens } from "@/hooks/solana/useSwapTokens"
import { useTokenBalance } from "@/hooks/solana/useTokenBalance"
import { getSolscanUrl } from "@/lib/solana/config"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TokenSelector } from "@/components/swap/token-selector"
import { SlippageSettings } from "@/components/swap/slippage-settings"
import { ArrowDown, Settings, Loader2, AlertCircle, Shield, Wallet, ExternalLink, CheckCircle } from "lucide-react"
import { LoginModal } from "@/components/auth/login-modal"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

const MOCK_TOKENS = [
  { symbol: "RIAL", name: "Rialo Token", icon: "RIAL", mint: process.env.NEXT_PUBLIC_RIAL_MINT || "TokenkegQfeZyiNwAJsyFbPVwwQQftas5call5pVM5gdk" },
  { symbol: "SOL", name: "Solana", icon: "SOL", mint: "So11111111111111111111111111111111111111112" },
  { symbol: "USDC", name: "USD Coin", icon: "USDC", mint: "4zMMC9srt5Ri5X14Gye5QZ5yi9GeZymQuNCjaSstB5Ty" },
  { symbol: "USDT", name: "Tether", icon: "USDT", mint: "FWbnQfnMvYnjJaQwxULR2xkwx1h7gzCu1fK5cRkxsf9E" },
  { symbol: "WRAPPED_SOL", name: "Wrapped SOL", icon: "SOL", mint: "So11111111111111111111111111111111111111112" },
]

// Helper to render token icons
const getTokenIcon = (icon: string) => {
  const iconMap: Record<string, string> = {
    RIAL: "⊙",
    SOL: "◎",
    USDC: "◆",
    USDT: "T",
    WRAPPED_SOL: "◎",
  }
  return iconMap[icon] || "◇"
}

export function SwapPanel() {
  const { address, isConnected } = useWeb3()
  const { user, request2FAConfirmation } = useAuth()
  const { state: swapState, executeSwap, reset: resetSwap } = useSwapTokens(address)
  const [fromToken, setFromToken] = useState(MOCK_TOKENS[0])
  const [toToken, setToToken] = useState(MOCK_TOKENS[1])
  const [fromAmount, setFromAmount] = useState("")
  const [toAmount, setToAmount] = useState("")
  const [slippage, setSlippage] = useState("0.5")
  const [showSettings, setShowSettings] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)

  // Get real balances from blockchain
  const fromBalance = useTokenBalance(address, fromToken.mint)
  const toBalance = useTokenBalance(address, toToken.mint)

  // Mock price calculation for UI display
  const mockPrices: Record<string, number> = {
    RIAL: 0.50,
    SOL: 145,
    USDC: 1,
    USDT: 1,
    WRAPPED_SOL: 145,
  }

  const handleFromAmountChange = (value: string) => {
    setFromAmount(value)
    if (value && !isNaN(Number(value))) {
      const fromPrice = mockPrices[fromToken.symbol] || 1
      const toPrice = mockPrices[toToken.symbol] || 1
      const converted = (Number(value) * fromPrice) / toPrice
      setToAmount(converted.toFixed(6))
    } else {
      setToAmount("")
    }
  }

  const handleSwapTokens = () => {
    const temp = fromToken
    setFromToken(toToken)
    setToToken(temp)
    setFromAmount(toAmount)
    setToAmount(fromAmount)
  }

  const handleSwap = async () => {
    if (!isConnected || !address) {
      setShowLoginModal(true)
      return
    }

    // Request 2FA confirmation if enabled
    if (user?.is2FAEnabled) {
      const confirmed = await request2FAConfirmation("Swap Tokens")
      if (!confirmed) return
    }

    try {
      if (!fromToken.mint || !toToken.mint) {
        console.error("[v0] Invalid token mints:", { from: fromToken.mint, to: toToken.mint })
        // Proceed with swap anyway - API will handle mock data
      }
      
      await executeSwap(fromToken.mint || "", toToken.mint || "", fromAmount, Number(slippage))
      // Clear amounts after successful swap
      setFromAmount("")
      setToAmount("")
    } catch (err) {
      console.error("[v0] Swap error:", err)
    }
  }

  // Update balances on successful swap (only once per transaction)
  useEffect(() => {
    if (swapState.txHash && fromAmount && toAmount && !swapState.balanceUpdated) {
      // Mark that we've updated balance for this transaction
      const currentFrom = parseFloat(fromBalance.uiAmount) || 0
      const newFromBalance = (currentFrom - parseFloat(fromAmount)).toFixed(6)
      
      const currentTo = parseFloat(toBalance.uiAmount) || 0
      const newToBalance = (currentTo + parseFloat(toAmount)).toFixed(6)
      
      // Update balance in localStorage directly
      const fromKey = `balance_${address}_${fromToken.symbol}`
      const toKey = `balance_${address}_${toToken.symbol}`
      localStorage.setItem(fromKey, JSON.stringify({ amount: newFromBalance, decimals: fromBalance.decimals }))
      localStorage.setItem(toKey, JSON.stringify({ amount: newToBalance, decimals: toBalance.decimals }))
      
      console.log(`[v0] Balance updated: ${fromToken.symbol} ${newFromBalance}, ${toToken.symbol} ${newToBalance}`)
    }
  }, [swapState.txHash])

  const priceImpact = fromAmount ? (Math.random() * 0.5 + 0.01).toFixed(2) : "0.00"
  const exchangeRate =
    fromToken && toToken ? (mockPrices[fromToken.symbol] / mockPrices[toToken.symbol]).toFixed(6) : "0"

  return (
    <>
      <Card className="w-full max-w-md border-border bg-card shadow-xl">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold">Swap</CardTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowSettings(!showSettings)}
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </CardHeader>

        {showSettings && (
          <div className="px-6 pb-4">
            <SlippageSettings slippage={slippage} setSlippage={setSlippage} />
          </div>
        )}

        <CardContent className="space-y-4">
          {/* Swap Success Alert */}
          {swapState.txHash && (
            <Alert className="border-green-500/50 bg-green-500/10">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <AlertTitle className="text-green-500">Swap Successful!</AlertTitle>
              <AlertDescription className="space-y-2 mt-2">
                <p className="text-sm">Successfully swapped {fromToken.symbol} for {toToken.symbol}</p>
                <a
                  href={getSolscanUrl(swapState.txHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-primary hover:underline text-sm"
                >
                  View on Solscan
                  <ExternalLink className="h-3 w-3" />
                </a>
              </AlertDescription>
            </Alert>
          )}

          {/* From Token */}
          <div className="rounded-xl bg-secondary/50 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">You pay</span>
              <span className="text-sm text-muted-foreground">
                Balance: {fromBalance.isLoading ? "..." : fromBalance.uiAmount} {fromToken.symbol}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={fromAmount}
                onChange={(e) => handleFromAmountChange(e.target.value)}
                placeholder="0.0"
                className="flex-1 bg-transparent text-2xl font-medium outline-none placeholder:text-muted-foreground/50"
              />
              <TokenSelector
                selected={fromToken}
                onSelect={setFromToken}
                tokens={MOCK_TOKENS.filter((t) => t.symbol !== toToken.symbol)}
              />
            </div>
            {fromAmount && (
              <p className="text-sm text-muted-foreground mt-1">
                ≈ ${(Number(fromAmount) * mockPrices[fromToken.symbol]).toLocaleString()}
              </p>
            )}
          </div>

          {/* Swap Button */}
          <div className="flex justify-center -my-1 relative z-10">
            <button
              onClick={handleSwapTokens}
              className="flex h-10 w-10 items-center justify-center rounded-xl border-4 border-card bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors"
            >
              <ArrowDown className="h-4 w-4" />
            </button>
          </div>

          {/* To Token */}
          <div className="rounded-xl bg-secondary/50 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">You receive</span>
              <span className="text-sm text-muted-foreground">
                Balance: {toBalance.isLoading ? "..." : toBalance.uiAmount} {toToken.symbol}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={toAmount}
                readOnly
                placeholder="0.0"
                className="flex-1 bg-transparent text-2xl font-medium outline-none placeholder:text-muted-foreground/50"
              />
              <TokenSelector
                selected={toToken}
                onSelect={setToToken}
                tokens={MOCK_TOKENS.filter((t) => t.symbol !== fromToken.symbol)}
              />
            </div>
            {toAmount && (
              <p className="text-sm text-muted-foreground mt-1">
                ≈ ${(Number(toAmount) * mockPrices[toToken.symbol]).toLocaleString()}
              </p>
            )}
          </div>

          {/* Swap Details */}
          {fromAmount && toAmount && (
            <div className="rounded-lg bg-secondary/30 p-3 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Rate</span>
                <span className="text-foreground">
                  1 {fromToken.symbol} = {exchangeRate} {toToken.symbol}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Price Impact</span>
                <span className={Number(priceImpact) > 1 ? "text-yellow-500" : "text-green-500"}>{priceImpact}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Max Slippage</span>
                <span className="text-foreground">{slippage}%</span>
              </div>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex flex-col gap-3">
          {!isConnected ? (
            <Button onClick={() => setShowLoginModal(true)} className="w-full h-12 text-base gap-2">
              <Wallet className="h-5 w-5" />
              Connect Wallet
            </Button>
          ) : !fromAmount || Number(fromAmount) === 0 ? (
            <Button disabled className="w-full h-12 text-base">
              Enter an amount
            </Button>
          ) : Number(fromAmount) > Number(fromBalance.uiAmount || 0) ? (
            <Button disabled variant="destructive" className="w-full h-12 text-base gap-2">
              <AlertCircle className="h-5 w-5" />
              Insufficient {fromToken.symbol} balance
            </Button>
          ) : swapState.error ? (
            <Button disabled variant="destructive" className="w-full h-12 text-base gap-2">
              <AlertCircle className="h-5 w-5" />
              {swapState.error}
            </Button>
          ) : (
            <Button onClick={handleSwap} disabled={swapState.isLoading} className="w-full h-12 text-base gap-2">
              {swapState.isLoading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Swapping...
                </>
              ) : swapState.txHash ? (
                <>
                  ✓ Swap Complete
                </>
              ) : (
                "Swap"
              )}
            </Button>
          )}

          {user?.is2FAEnabled && isConnected && (
            <div className="flex items-center justify-center gap-2 text-xs text-primary">
              <Shield className="h-3 w-3" />
              <span>Protected by Rialo 2FA</span>
            </div>
          )}
        </CardFooter>
      </Card>

      <LoginModal open={showLoginModal} onOpenChange={setShowLoginModal} />
    </>
  )
}
