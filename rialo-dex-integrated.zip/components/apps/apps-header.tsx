"use client"

import { useState } from "react"
import { usePathname } from "next/navigation"
import { useWeb3 } from "@/components/providers/web3-provider"
import { useAuth } from "@/components/providers/auth-provider"
import { LoginModal } from "@/components/auth/login-modal"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Wallet, Loader2, LogOut, User, Shield, ChevronDown, Copy, ExternalLink } from "lucide-react"

function formatAddress(address: string) {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

const pageTitles: Record<string, string> = {
  "/apps/markets": "Markets",
  "/apps/swap": "Swap",
  "/apps/bridge": "Bridge",
  "/apps/faucet": "Faucet",
  "/apps/profile": "Profile",
  "/apps/security": "Security",
}

export function AppsHeader() {
  const pathname = usePathname()
  const { address, isConnected, isConnecting, connect, disconnect, chainId } = useWeb3()
  const { user, isAuthenticated, logout } = useAuth()
  const [showLoginModal, setShowLoginModal] = useState(false)

  const pageTitle = pageTitles[pathname] || "Dashboard"

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-4 lg:px-6">
          {/* Page Title */}
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-semibold text-foreground">{pageTitle}</h1>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-3">
            {/* Network Badge */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary text-xs font-medium text-muted-foreground">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              Solana Testnet
            </div>

            {/* User Menu */}
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="gap-2 bg-transparent">
                    {user?.googleAvatar ? (
                      <img src={user.googleAvatar || "/placeholder.svg"} alt="" className="h-5 w-5 rounded-full" />
                    ) : (
                      <User className="h-4 w-4" />
                    )}
                    <span className="hidden sm:inline">
                      {isConnected && address ? formatAddress(address) : user?.googleName || "Account"}
                    </span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64">
                  {isConnected && address && (
                    <>
                      <div className="px-2 py-1.5">
                        <p className="text-sm font-medium">{formatAddress(address)}</p>
                        <p className="text-xs text-muted-foreground">Connected Wallet</p>
                      </div>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigator.clipboard.writeText(address)}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Address
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => window.open(`https://explorer.solana.com/address/${address}?cluster=testnet`, "_blank")}
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View on Solana Explorer
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  {user?.googleEmail && (
                    <>
                      <div className="px-2 py-1.5">
                        <p className="text-sm font-medium">{user.googleName}</p>
                        <p className="text-xs text-muted-foreground">{user.googleEmail}</p>
                      </div>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  {user?.is2FAEnabled && (
                    <div className="px-2 py-1.5 mx-2 my-1 rounded bg-primary/10 border border-primary/20">
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-primary" />
                        <div>
                          <p className="text-xs font-medium text-primary">2FA Active</p>
                          <p className="text-xs text-muted-foreground">Rialo Protocol</p>
                        </div>
                      </div>
                    </div>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                {isConnecting ? (
                  <Button disabled className="gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Connecting...
                  </Button>
                ) : isConnected && address ? (
                  <Button variant="outline" className="gap-2 bg-transparent" onClick={() => setShowLoginModal(true)}>
                    <Wallet className="h-4 w-4" />
                    {formatAddress(address)}
                  </Button>
                ) : (
                  <Button onClick={() => setShowLoginModal(true)} className="gap-2">
                    <Wallet className="h-4 w-4" />
                    Sign In
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </header>

      <LoginModal open={showLoginModal} onOpenChange={setShowLoginModal} />
    </>
  )
}
