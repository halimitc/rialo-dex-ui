"use client"

import { useState } from "react"
import { useWeb3 } from "@/components/providers/web3-provider"
import { useAuth } from "@/components/providers/auth-provider"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Wallet, Loader2, CheckCircle, Shield } from "lucide-react"

interface LoginModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function LoginModal({ open, onOpenChange }: LoginModalProps) {
  const { connect, isConnecting, isConnected, address } = useWeb3()
  const { user, loginWithGoogle, isAuthenticated } = useAuth()
  const [isGoogleLoading, setIsGoogleLoading] = useState(false)

  const handleGoogleLogin = async () => {
    setIsGoogleLoading(true)
    try {
      await loginWithGoogle()
    } catch (error) {
      console.error("Google login failed:", error)
    } finally {
      setIsGoogleLoading(false)
    }
  }

  const handleWalletConnect = async () => {
    await connect()
  }

  // Close modal if fully authenticated
  if (isAuthenticated && isConnected && user?.googleEmail) {
    if (open) {
      setTimeout(() => onOpenChange(false), 500)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md border-border bg-card">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">Sign in to Rialo</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Wallet Connection */}
          <div className="space-y-2">
            <Button
              variant={isConnected ? "outline" : "default"}
              className="w-full h-14 justify-start gap-4 text-left"
              onClick={handleWalletConnect}
              disabled={isConnecting}
            >
              {isConnecting ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : isConnected ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <Wallet className="h-5 w-5" />
              )}
              <div className="flex-1">
                <div className="font-medium">{isConnected ? "Wallet Connected" : "Connect Wallet"}</div>
                <div className="text-xs text-muted-foreground">
                  {isConnected && address
                    ? `${address.slice(0, 6)}...${address.slice(-4)}`
                    : "MetaMask, WalletConnect, etc."}
                </div>
              </div>
            </Button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>

          {/* Google Login */}
          <Button
            variant={user?.googleEmail ? "outline" : "secondary"}
            className="w-full h-14 justify-start gap-4 text-left"
            onClick={handleGoogleLogin}
            disabled={isGoogleLoading}
          >
            {isGoogleLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : user?.googleEmail ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
            )}
            <div className="flex-1">
              <div className="font-medium">{user?.googleEmail ? "Google Connected" : "Login with Google"}</div>
              <div className="text-xs text-muted-foreground">{user?.googleEmail || "Link your Google account"}</div>
            </div>
          </Button>

          {/* 2FA Status */}
          {isAuthenticated && (
            <div className="rounded-lg border border-primary/30 bg-primary/5 p-4">
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-primary" />
                <div>
                  <div className="text-sm font-medium text-foreground">
                    2FA Status: {user?.is2FAEnabled ? "Active" : "Inactive"}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {user?.is2FAEnabled ? "Rialo Native 2FA Protocol Enabled" : "Enable 2FA for enhanced security"}
                  </div>
                </div>
                {user?.is2FAEnabled && <CheckCircle className="h-5 w-5 text-green-500 ml-auto" />}
              </div>
            </div>
          )}
        </div>

        {isAuthenticated && (
          <Button onClick={() => onOpenChange(false)} className="w-full">
            Continue to App
          </Button>
        )}
      </DialogContent>
    </Dialog>
  )
}
