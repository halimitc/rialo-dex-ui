'use client'

import { useCallback, useState } from 'react'
import { FAUCET_CONFIG } from '@/lib/solana/config'

export interface FaucetRequest {
  isLoading: boolean
  error: string | null
  txHash: string | null
  cooldownRemaining: number
  requestFaucet: () => Promise<void>
  reset: () => void
}

export function useRequestFaucet(walletAddress: string | null): FaucetRequest {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [txHash, setTxHash] = useState<string | null>(null)
  const [cooldownRemaining, setCooldownRemaining] = useState(0)

  const requestFaucet = useCallback(async () => {
    if (!walletAddress) {
      setError('Wallet not connected')
      return
    }

    setIsLoading(true)
    setError(null)
    setTxHash(null)

    try {
      // Call backend API route instead of using Solana packages directly
      const response = await fetch('/api/solana/faucet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ walletAddress }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || 'Faucet request failed')
      }

      const data = await response.json()
      setTxHash(data.txHash)

      // Set cooldown
      const cooldownMs = FAUCET_CONFIG.cooldownSeconds * 1000
      setCooldownRemaining(cooldownMs)

      // Countdown timer
      const interval = setInterval(() => {
        setCooldownRemaining((prev) => {
          if (prev <= 1000) {
            clearInterval(interval)
            return 0
          }
          return prev - 1000
        })
      }, 1000)

      console.log('[v0] Faucet request successful:', data.txHash)
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Faucet request failed'
      setError(errorMsg)
      console.error('[v0] Faucet error:', errorMsg)
    } finally {
      setIsLoading(false)
    }
  }, [walletAddress])

  const reset = useCallback(() => {
    setError(null)
    setTxHash(null)
    setCooldownRemaining(0)
  }, [])

  return {
    isLoading,
    error,
    txHash,
    cooldownRemaining,
    requestFaucet,
    reset,
  }
}
