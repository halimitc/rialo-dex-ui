'use client'

import { useCallback, useState, useEffect } from 'react'

export interface TokenBalance {
  amount: string
  decimals: number
  uiAmount: string
  isLoading: boolean
  error: string | null
  refresh: () => Promise<void>
  updateBalance: (newAmount: string | number) => void
}

// Helper to format token amounts
function formatTokenAmount(amount: bigint, decimals: number): string {
  const divisor = BigInt(Math.pow(10, decimals))
  const wholePart = amount / divisor
  const fractionalPart = amount % divisor
  const fractionalStr = fractionalPart.toString().padStart(decimals, '0')
  return `${wholePart}.${fractionalStr}`.replace(/\.?0+$/, '')
}

export function useTokenBalance(walletAddress: string | null, tokenMint: string | null): TokenBalance {
  const [amount, setAmount] = useState('0')
  const [decimals, setDecimals] = useState(6)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchBalance = useCallback(async () => {
    if (!walletAddress) {
      setAmount('0')
      return
    }

    // Determine token symbol from mint or use default
    let tokenSymbol = 'RIAL'
    if (tokenMint?.includes('So11') || tokenMint === 'native' || tokenMint?.includes('SOL')) {
      tokenSymbol = 'SOL'
    } else if (tokenMint?.includes('4zMM')) {
      tokenSymbol = 'USDC'
    } else if (tokenMint?.includes('USDT')) {
      tokenSymbol = 'USDT'
    }

    setIsLoading(true)
    setError(null)

    try {
      // Get balance from localStorage if available (for persistent state across swaps)
      const storageKey = `balance_${walletAddress}_${tokenSymbol}`
      const storedBalance = localStorage.getItem(storageKey)
      
      if (storedBalance) {
        const parsed = JSON.parse(storedBalance)
        setAmount(parsed.amount)
        setDecimals(parsed.decimals)
        setIsLoading(false)
        return
      }

      // Call backend API route for initial balance
      const response = await fetch(`/api/solana/balance?wallet=${walletAddress}&token=${tokenSymbol}`)
      
      if (!response.ok) {
        throw new Error('Failed to fetch balance')
      }

      const data = await response.json()
      const balanceData = {
        amount: data.balance.amount,
        decimals: data.balance.decimals,
      }
      
      // Store balance in localStorage for persistence
      localStorage.setItem(storageKey, JSON.stringify(balanceData))
      
      setAmount(data.balance.amount)
      setDecimals(data.balance.decimals)
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to fetch balance'
      setError(errorMsg)
      console.error('[v0] Balance fetch error:', errorMsg)
    } finally {
      setIsLoading(false)
    }
  }, [walletAddress, tokenMint])

  // Auto-refresh on mount and when wallet/token changes
  useEffect(() => {
    fetchBalance()
  }, [fetchBalance])

  const updateBalance = useCallback((newAmount: string | number) => {
    const newAmountStr = typeof newAmount === 'number' ? newAmount.toString() : newAmount
    setAmount(newAmountStr)
    
    // Update localStorage
    if (walletAddress && tokenMint) {
      let tokenSymbol = 'RIAL'
      if (tokenMint?.includes('So11') || tokenMint === 'native' || tokenMint?.includes('SOL')) {
        tokenSymbol = 'SOL'
      } else if (tokenMint?.includes('4zMM')) {
        tokenSymbol = 'USDC'
      } else if (tokenMint?.includes('USDT')) {
        tokenSymbol = 'USDT'
      }
      
      const storageKey = `balance_${walletAddress}_${tokenSymbol}`
      localStorage.setItem(storageKey, JSON.stringify({ amount: newAmountStr, decimals }))
    }
  }, [walletAddress, tokenMint, decimals])

  // Convert string amount to BigInt, handling both decimal and integer strings
  const getAmountAsBigInt = (amountStr: string): bigint => {
    // If amount contains decimal, convert to integer by multiplying by 10^decimals
    if (amountStr.includes('.')) {
      const [whole, fractional] = amountStr.split('.')
      const paddedFractional = (fractional || '0').padEnd(decimals, '0').slice(0, decimals)
      return BigInt(whole + paddedFractional)
    }
    // Already an integer in smallest unit
    return BigInt(amountStr || '0')
  }
  
  const uiAmount = formatTokenAmount(getAmountAsBigInt(amount), decimals)

  return {
    amount,
    decimals,
    uiAmount,
    isLoading,
    error,
    refresh: fetchBalance,
    updateBalance,
  }
}
