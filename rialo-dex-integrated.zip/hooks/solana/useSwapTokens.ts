'use client'

import { useCallback, useState } from 'react'

export interface SwapState {
  isLoading: boolean
  error: string | null
  txHash: string | null
  outputAmount: string
  priceImpact: number
}

export interface SwapResult {
  state: SwapState
  executeSwap: (inputMint: string, outputMint: string, inputAmount: string, slippage: number) => Promise<void>
  reset: () => void
}

export function useSwapTokens(walletAddress: string | null): SwapResult {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [txHash, setTxHash] = useState<string | null>(null)
  const [outputAmount, setOutputAmount] = useState('0')
  const [priceImpact, setPriceImpact] = useState(0)

  const executeSwap = useCallback(
    async (inputMint: string, outputMint: string, inputAmount: string, slippage: number) => {
      if (!walletAddress) {
        setError('Wallet not connected')
        return
      }

      setIsLoading(true)
      setError(null)
      setTxHash(null)

      try {
        // Call backend API route instead of using Solana packages directly
        const response = await fetch('/api/solana/swap', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            walletAddress,
            inputMint,
            outputMint,
            inputAmount,
            slippageBps: Math.floor(slippage * 100),
          }),
        })

        if (!response.ok) {
          const data = await response.json()
          throw new Error(data.error || 'Swap failed')
        }

        const data = await response.json()
        setTxHash(data.txHash)
        setOutputAmount(data.outputAmount)

        console.log('[v0] Swap successful:', data.txHash)
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Swap failed'
        setError(errorMsg)
        console.error('[v0] Swap error:', errorMsg)
      } finally {
        setIsLoading(false)
      }
    },
    [walletAddress]
  )

  const reset = useCallback(() => {
    setError(null)
    setTxHash(null)
    setOutputAmount('0')
    setPriceImpact(0)
  }, [])

  return {
    state: {
      isLoading,
      error,
      txHash,
      outputAmount,
      priceImpact,
    },
    executeSwap,
    reset,
  }
}
